# README

# Directory navigation
- ./out/ This is a folder containing all of the drafted application materials
- ./src/ This is a folder containing the files used to generate the files in the out/ subdirectory

# Checklist of items for application
x Proposal Summary
x Project description and research plan
x Other sources of support
x Professional development plan
x Biographical sketch
- Budget and budget justification
- Data Management Plan
- Advisor Support form
- Institutional Support form
- Research and professional Ethics Requirements (evidence of IRB approval)